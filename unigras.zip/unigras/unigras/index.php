<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>
  UNIGRAS | FESC
    </title>
    
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,600,600i,700,700i,900" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">
  
</head>

<body>

 <!--inicia menu-->
  <?php include("menu.html");?>
    <!--termina menu-->
 

  <!-- ======= Breadcrumbs Section ======= -->
    <section class="breadcrumbs">
      <div class="container">
       <h2>UNIDAD DE INVESTIGACIÓN EN GRANOS Y SEMILLAS (UNIGRAS)</h2>
       </div>
     </section>
  <!-- End Breadcrumbs Section -->


 
 <!--Comienza slider-->
  <div class="container">
    <div id="carouselIndicators" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#carouselIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
    <button type="button" data-bs-target="#carouselIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
    <button type="button" data-bs-target="#carouselIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
    <button type="button" data-bs-target="#carouselIndicators" data-bs-slide-to="3" aria-label="Slide 4"></button>
  </div>
  <div class="carousel-inner" style="height:90%">
  
    <div class="carousel-item active">
      <a href="descargas/NotiFESC.pdf" target="_blank"><img src="img/banner/1.jpg" class="d-block w-100" alt=""></a>
    </div>
    <div class="carousel-item">
      <a href="descargas/Horarios_transporte.pdf" target="_blank"><img src="img/banner/2.jpg" class="d-block w-100" alt="..."></a>
    </div>
    <div class="carousel-item">
      <a href="https://w2.cuautitlan.unam.mx/descargas/carteles/Calendario_2025_1.pdf" target="_blank"><img src="img/banner/3.jpg" class="d-block w-100"></a>
    </div>
     <div class="carousel-item">
      <a href="descargas/Vinculo_fesc.pdf" target="_blank"><img src="img/banner/4.jpg" class="d-block w-100" alt="..."></a>
    </div>
  </div>
 
</div>
</div>
 <!--termina slider-->

  <div class="container">
   <div class="col-12">
    
    
    <div class="section-title">
      <h2>MISIÓN</h2>
    </div>
    <p>La misión fundamental de la UNIGRAS es desarrollar       investigación de excelencia académica en el
    área de Poscosecha de Granos y Semillas, que contribuya a mantener la calidad, la cantidad e
    inocuidad de éstos; así como de los productos que se elaboran con ellos. Aunado a lo anterior, es
    de gran importancia la formación de recursos humanos especializados en el área, con la
    participación multi e interdisciplinaria de los integrantes de la FES Cuautitlán y de otras
    instituciones a nivel nacional e internacional.</p>
      
    <div class="section-title">
      <h2>VISIÓN</h2>
    </div>
    <p>Aportar información científica sobre el manejo Poscosecha de Granos y Semillas, para el ámbito
    académico, profesionistas y técnicos del sector agrícola, público y privado, que coadyuven a la
    conservación de estos insumos de calidad, importantes para la alimentación humana y animal.</p>

    <div class="section-title">
      <h2>OBJETIVOS</h2>
    </div>
    <p>Desarrollar investigación básica y aplicada sobre Poscosecha de Granos y Semillas, con la
    participación de académicos y estudiantes a nivel de licenciatura y posgrado, de la FESC, de otras
    dependencias de la UNAM y de otras instituciones.</p>

    <div class="section-title">
      <h2>FUNCIONES</h2>
    </div>
    <ul>
          <li>Realizar investigación científica básica y aplicada, que genere conocimientos para aminorar las
          costosas pérdidas cualitativas y cuantitativas, que pueden ocurrir en los granos y las semillas.</li>
          <li>Vincular al claustro académico de UNIGRAS con sus pares de otras Instituciones públicas y
          privadas, a nivel multi e interdisciplinario nacional e internacional, para realizar investigación que
          logre impacto en la preservación de granos y semillas.</li>
          <li>Proyectar los resultados de la investigación mediante su publicación en Revistas especializadas,
          Foros, Simposios, Congresos y Cursos. Difundir el conocimiento de los granos y las semillas
          mediante la publicación de Trípticos, Folletos, Manuales y Libros; así como el uso de las
          tecnologías de la información y la comunicación para lograr una difusión amplia acerca de la
          poscosecha de granos y semillas.</li>
          <li>Formar recursos humanos especializados, a través de su incorporación en los diferentes proyectos
          de investigación, actividades de servicio social, estancias de investigación, prácticas curriculares de
          licenciatura, tesis, etc. de las carrereas de Ingeniería Agrícola, Ing. en Alimentos, Medicina
          Veterinaria y Zootecnia, Biología y otras afines; así como de posgrado de la UNAM y de otras
          instituciones nacionales e internacionales. Realización de cursos de actualización para personal del
          sector agrícola.</li>
          <li>Prestar servicios relacionados con el análisis de la calidad de granos y semillas: físico, fisiológico,
          bioquímico, sanitario (insectos y hongos), fitopatológico (hongos, bacterias. virus, nemátodos).
          Pruebas de efectividad biológica de productos para el manejo poscosecha de granos y semillas.
          Sistemas de almacenamiento de granos. Análisis de inocuidad (micotoxinas) y otros, para el sector
          agropecuario, público y privado.</li>
          <li>Obtener productos procesados de calidad, a partir de granos y semillas conservados de manera
          óptima; así como realizar consultorías al respecto.</li> 
    </ul>
   </div>
  </div>
  <br>
   
   <section id="portfolio-details" class="portfolio-details">
<div class="container" data-aos="fade-up">

<div class="row gy-4">

<div class="col-lg-5">
 <div class="portfolio-info">
  
    <p><strong>CONTACTO</strong><br>
    DRA. ROSA NAVARRETE MAYA<br>
    UNIGRAS, FESC, UNAM<br>
    Tels. 55 58 80 93 16, 55 58 80 94 40<br>
    rosanavarretem@cuautitlan.unam.mx<br>
    rosanavarretemaya@gmail.com<br><br>
    <strong>UBICACIÓN</strong><br> Centro de Asimilación Tecnológica y Vinculación<br>
    Av. Dr. J. Jiménez Cantú s/n, Col Atlamica<br>
    Cuautitlán Izcalli, Edo. de México, CP. 54729<br>

<hr>
       
   <a href="https://www.google.com.mx/maps/place/UNAM+-+Centro+de+Asimilaci%C3%B3n+Tecnol%C3%B3gica/@19.6731603,-99.2114285,17z/data=!3m1!4b1!4m6!3m5!1s0x85d21fc9a6b9fcf7:0x875cfdf4e2a265c7!8m2!3d19.6731603!4d-99.2088536!16s%2Fg%2F12hl08js7?entry=ttu&g_ep=EgoyMDI0MDkwNC4wIKXMDSoASAFQAw%3D%3D">
            Ver ubicaci&oacute;n en Google Maps</a></p>
    
   </div>
  </div>

<div class="col-lg-7">
<iframe
    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3756.9260453864836!2d-99.2114285249323!3d19.67316028165827!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x85d21fc9a6b9fcf7%3A0x875cfdf4e2a265c7!2sUNAM%20-%20Centro%20de%20Asimilaci%C3%B3n%20Tecnol%C3%B3gica!5e0!3m2!1ses-419!2smx!4v1725959305138!5m2!1ses-419!2smx"
    width="100%" height="500" frameborder="0" style="border:0; margin-bottom:20px"
    allowfullscreen></iframe></div>


</div>
</div>
</section>

  </div>
    </div>

   

  
  <!-- ======= Footer ======= -->
   <?php include("footer.html");?>
    <!-- End Footer -->

  
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>
  
  <!-- Vendor JS Files -->
  <script src="assets/vendor/purecounter/purecounter.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>
  
</body>
</html>